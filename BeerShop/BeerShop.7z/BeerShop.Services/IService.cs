﻿namespace BeerShop.Services
{
    public interface IService
    {
    }
}
