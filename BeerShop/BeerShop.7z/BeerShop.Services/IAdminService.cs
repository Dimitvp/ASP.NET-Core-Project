﻿namespace BeerShop.Services
{
    using BeerShop.Services.Models.Admins;
    using System.Collections.Generic;

    public interface IAdminService
    {
        IEnumerable<UserListingModel> AllUsers();

        UserDetailsModel UserById(string id);
    }
}
