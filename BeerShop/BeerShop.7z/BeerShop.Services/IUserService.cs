﻿namespace BeerShop.Services
{
    public interface IUserService
    {
        void SetLoginTime();
    }
}
