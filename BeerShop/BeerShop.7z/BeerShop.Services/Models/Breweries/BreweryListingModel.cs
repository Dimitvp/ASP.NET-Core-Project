﻿namespace BeerShop.Services.Models.Breweries
{
    public class BreweryListingModel
    {

    }
}
