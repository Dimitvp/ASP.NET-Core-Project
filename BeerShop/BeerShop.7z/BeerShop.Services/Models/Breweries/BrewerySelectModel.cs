﻿namespace BeerShop.Services.Models.Breweries
{
    public class BrewerySelectModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
