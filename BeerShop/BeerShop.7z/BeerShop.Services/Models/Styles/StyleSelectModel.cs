﻿namespace BeerShop.Services.Models.Styles
{
    public class StyleSelectModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
