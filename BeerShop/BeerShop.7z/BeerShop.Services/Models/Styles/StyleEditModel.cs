﻿namespace BeerShop.Services.Models.Styles
{
    public class StyleEditModel
    {
        public string Name { get; set; }

        public string ServingTemp { get; set; }
    }
}
