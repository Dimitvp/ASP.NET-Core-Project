﻿namespace BeerShop.Services.Models.Styles
{
    public class StyleListingModel : StyleEditModel
    {
        public int Id { get; set; }
    }
}
