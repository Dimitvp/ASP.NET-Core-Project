﻿namespace BeerShop.Services.Models.Towns
{
    public class TownEditModel
    {
        public string Name { get; set; }

        public string ZipCode { get; set; }

        public int CountryId { get; set; }
    }
}
