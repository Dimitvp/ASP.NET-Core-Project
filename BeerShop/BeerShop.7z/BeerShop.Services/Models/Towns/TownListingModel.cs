﻿namespace BeerShop.Services.Models.Towns
{
    public class TownListingModel : TownEditModel
    {
        public int Id { get; set; }

        public string CountryName { get; set; }
    }
}
