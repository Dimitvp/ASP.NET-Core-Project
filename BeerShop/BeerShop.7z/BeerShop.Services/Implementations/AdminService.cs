﻿namespace BeerShop.Services.Implementations
{
    using BeerShop.Data;
    using Models.Admins;
    using System.Collections.Generic;
    using System.Linq;

    public class AdminService : IAdminService
    {
        private readonly BeerShopDbContext db;

        public AdminService(BeerShopDbContext db)
        {
            this.db = db;
        }

        public IEnumerable<UserListingModel> AllUsers()
            => this.db.Users
                .Select(u => new UserListingModel
                {
                    Id = u.Id,
                    Email = u.Email,
                    Username = u.UserName
                })
                .ToList();

        public UserDetailsModel UserById(string id)
            => this.db.Users
                .Where(u => u.Id == id)
                .Select(u => new UserDetailsModel
                {
                    Username = u.UserName,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    Address = u.Address,
                    OrdersCount = u.Orders.Count,
                    RegisteredOn = u.RegisteredOn,
                    LastLogin = u.LastLogin
                })
                .FirstOrDefault();
    }
}
