﻿namespace BeerShop.Models
{
    using BeerShop.Models.Enums;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Country
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        public Continent Continent { get; set; }

        public ICollection<Town> Towns { get; set; } = new HashSet<Town>();
    }
}