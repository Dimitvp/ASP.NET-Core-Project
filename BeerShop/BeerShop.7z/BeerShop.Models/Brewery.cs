﻿namespace BeerShop.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Brewery
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        [MaxLength(200)]
        public string Adress { get; set; }

        public int TownId { get; set; }

        public Town Town { get; set; }

        public ICollection<Beer> Beers { get; set; } = new HashSet<Beer>();
    }
}
