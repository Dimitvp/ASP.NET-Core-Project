﻿namespace BeerShop.Models
{
    using Microsoft.AspNetCore.Identity;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class User : IdentityUser
    {
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; }

        [Required]
        [MaxLength(1000)]
        public string Address { get; set; }

        public DateTime RegisteredOn { get; set; }

        public DateTime LastLogin { get; set; }

        public ICollection<Order> Orders { get; set; } = new HashSet<Order>();
    }
}
