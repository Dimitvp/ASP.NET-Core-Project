﻿namespace BeerShop.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Style
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        [MaxLength(10)]
        public string ServingTemp { get; set; }

        public ICollection<Beer> Beers { get; set; } = new HashSet<Beer>();
    }
}