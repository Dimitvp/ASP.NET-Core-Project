﻿namespace BeerShop.Models.Enums
{
    public enum LogType
    {
        Create = 0,
        Edit = 1,
        Delete = 2
    }
}
