﻿namespace BeerShop.Models.Enums
{
    public enum Continent
    {
        Africa = 1,
        Asia = 2,
        Europe = 3,
        NorthAmerica = 4,
        SouthAmerica = 5,
        Antarctica = 6,
        Australia = 7
    }
}
