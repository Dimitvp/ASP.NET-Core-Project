﻿namespace BeerShop.Web.Infrastructure
{
    public class GlobalConstants
    {
        public const string AdminRole = "Admin";

        public const string ModeratorRole = "Moderator";
    }
}
